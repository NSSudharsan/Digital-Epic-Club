-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2019 at 02:35 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dec`
--

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `q_no` int(11) NOT NULL,
  `question` text,
  `ch1` varchar(100) DEFAULT NULL,
  `ch2` varchar(100) DEFAULT NULL,
  `ch3` varchar(100) DEFAULT NULL,
  `answer` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`q_no`, `question`, `ch1`, `ch2`, `ch3`, `answer`) VALUES
(1, 'The term Computer is derived from.......', 'Latin', 'German', 'French', 'Latin'),
(2, 'Which device is required for the Internet', 'Joystick', 'Modem', 'CD Drive', 'Modem'),
(3, 'Who is the father of Computer?', 'Allen Turing', 'Simur Cray', 'Charles Babbage', 'Charles Babbage'),
(4, 'LAN stands for...............', 'Limited Area Network', 'Logical Area Network', 'Local Area Network', 'Local Area Network'),
(6, 'IBM stands for', 'Internal Business Management', 'International Business Management', 'International Business Machines', 'International Business Machines'),
(7, 'Which of the following does not store data permanently?', 'ROM', 'RAM', 'Hard Disk', 'RAM'),
(8, 'The first web browser is', 'Mosaic', 'Netscape', 'Internet explorer', 'Mosaic'),
(9, 'Which programming languages are classified as low level languages?', 'BASIC, COBOL, Fortra', 'Assembly languages', 'C, C++', 'Assembly languages'),
(10, 'Who is the father of Computer science?', 'Allen Turing', 'Charles Babbage', 'Simur Cray', 'Allen Turing');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `n_user` int(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `score` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `college` varchar(100) CHARACTER SET utf8 NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `password` varchar(50) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `college`, `email`, `password`) VALUES
('karthik', 'rcet', 'karthiksoft3765@gmail.com', 'nsson'),
('sudharsan', 'rcet', 'nssudharsan1995@gmil.com', 'nss');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`q_no`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`n_user`,`name`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `q_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `n_user` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
